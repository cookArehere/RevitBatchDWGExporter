# -*- coding: utf-8 -*-
import os
import re
import clr

# Імпортуємо інструменти pyRevit для роботи з інтерфейсом та виходу зі скрипту
from pyrevit import forms, script

# Підключаємо Revit API
clr.AddReference('RevitAPI')
from Autodesk.Revit.DB import *

# Підключаємо класи .NET для роботи з колекціями
clr.AddReference('System')
from System.Collections.Generic import List

app = __revit__.Application

# --- ІНТЕРФЕЙС ДЛЯ ВИБОРУ ПАПОК ---

# 1. Запитуємо папку з файлами Revit
source_folder = forms.pick_folder(title="Звідки брати файли Revit? (Виберіть папку)")

# Перевіряємо, чи користувач не закрив вікно
if not source_folder:
    forms.alert("Папку джерела не вибрано. Експорт скасовано.", title="Увага", warn_icon=True)
    script.exit()

# 2. Запитуємо папку куди зберігати DWG
export_folder = forms.pick_folder(title="Куди експортувати DWG файли? (Виберіть папку)")

# Перевіряємо, чи користувач не закрив вікно
if not export_folder:
    forms.alert("Папку призначення не вибрано. Експорт скасовано.", title="Увага", warn_icon=True)
    script.exit()

# --- ОСНОВНА ЛОГІКА СКРИПТУ ---

# Отримуємо чисті файли (без бекапів)
all_files = os.listdir(source_folder)
rvt_files = [f for f in all_files if f.endswith('.rvt') and not re.search(r"\.\d{4}\.rvt$", f)]

if not rvt_files:
    forms.alert("У вибраній папці не знайдено файлів .rvt", title="Помилка", warn_icon=True)
    script.exit()

print("Знайдено проєктів для обробки: {}".format(len(rvt_files)))
print("-" * 50)

for filename in rvt_files:
    file_path = os.path.join(source_folder, filename)
    file_name_without_ext = os.path.splitext(filename)[0]

    print("Відкриття файлу: {}".format(filename))

    model_path = ModelPathUtils.ConvertUserVisiblePathToModelPath(file_path)
    open_options = OpenOptions()

    doc = None
    try:
        # Відкриваємо файл у фоновому режимі
        doc = app.OpenDocumentFile(model_path, open_options)

        collector = FilteredElementCollector(doc).OfClass(clr.GetClrType(View))
        view_ids = List[ElementId]()

        for view in collector:
            if view.IsTemplate:
                continue
            if view.ViewType == ViewType.DrawingSheet:
                view_ids.Add(view.Id)

        if view_ids.Count > 0:
            print("..Знайдено листів: {}. Експорт у DWG...".format(view_ids.Count))

            dwg_options = DWGExportOptions()
            dwg_options.FileVersion = ACADVersion.R2007
            dwg_options.MergedViews = True  # Об'єднуємо види, щоб не плодити сміття

            # Запускаємо експорт
            doc.Export(export_folder, file_name_without_ext, view_ids, dwg_options)
            print("..Успішно експортовано для: {}".format(filename))
        else:
            print("..У файлі {} не знайдено листів для експорту.".format(filename))

    except Exception as e:
        print("[ПОМИЛКА] Не вдалося обробити файл {}: {}".format(filename, str(e)))

    finally:
        if doc:
            doc.Close(False)
            print("Файл закрито.")
            print("-" * 50)

# Фінальне сповіщення на екрані, коли все закінчиться
forms.alert("Експорт повністю завершено!", title="Успіх", warn_icon=False)
print("Роботу завершено успішно!")